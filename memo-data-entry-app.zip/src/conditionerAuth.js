import React, { Component } from 'react';

class ConditionalAuth extends Component {
  constructor() {
    super();
    this.state = {
      isLoggedIn: false,
      username: '',
      password: '',
    };
  }

  handleLogin = () => {
    if (this.state.username === 'user' && this.state.password === 'password') {
      this.setState({ isLoggedIn: true });
    }
  }

  handleLogout = () => {
    this.setState({ isLoggedIn: false, username: '', password: '' });
  }

  handleInputChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  }

  render() {
    return (
      <div>
        <h1>Conditional Rendering Auth</h1>
        {this.state.isLoggedIn ? (
          <div>
            <p>
              Welcome to the site {this.state.username}
            </p>
            <button onClick={this.handleLogout}>
              Logout
            </button>
          </div>
        ) : (
          <div>
            <input type="text" name="username" placeholder="Username" value={this.state.username} onChange={this.handleInputChange}></input>
            <input type="password" name="password" placeholder="Password" value={this.state.password} onChange={this.handleInputChange}></input>
            <button onClick={this.handleLogin}>Login</button>
          </div>
        )}
      </div>
    );
  }
}

export default ConditionalAuth;
