import React from "react";

function Contact(){
    return(
        <div className="Contact">
            <h1>This is a Contact page </h1>
            <p>This is a react web page </p>
            <b>pakistan zindabad </b>
        </div>
    )
}

export default Contact;