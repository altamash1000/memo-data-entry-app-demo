import React , {useState} from "react";
const TodoList1 = ()=>{
    const [todos, setTodos] = useState([]);
    const [newTodo, setnewtodo] = useState("");

    const addTodo = () =>{
        if(newTodo !== ""){
            setTodos([...todos, newTodo]);
            setnewtodo("");
        }
    }

    return(
        <div>
            <ul>
                {todos.map((todo , index)=>{
                    <li key={index}>{todo}</li>
                })}
            </ul>

            <input type="text" value={newTodo} onChange={(e)=>setnewtodo(e.target.value)}></input>


            <button onClick={addTodo}>Add todo</button>
        </div>
    )

}

export default TodoList1;