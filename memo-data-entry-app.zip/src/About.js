import React from "react";

function About(){
    return(
        <div className="About">
            <h1>This is a About page </h1>
            <p>This is a react web page </p>
        </div>
    )
}

export default About;