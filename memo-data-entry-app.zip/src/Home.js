import React from "react";

function Home(){
    return(
        <div className="Home">
            <h1>This is a home page </h1>
        </div>
    )
}

export default Home;