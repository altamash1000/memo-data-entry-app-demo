
import React, { useState, useEffect } from 'react';
import './style.css';

const UserInfo = () => {
  const [userList, setUserList] = useState([]);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    city: '',
    country: '',
    address: '',
    phoneNumber: '',
    language: '',
    picture: null,
  });

  const [search, setSearch] = useState('');
  const [filteredUserList, setFilteredUserList] = useState([]);

  useEffect(() => {
    const filteredUsers = userList.filter((user) => {
      const name = `${user.firstName} ${user.lastName}`.toLowerCase();
      return name.includes(search.toLowerCase()) || user.phoneNumber.includes(search);
    });

    setFilteredUserList(filteredUsers);
  }, [search, userList]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();

      reader.onload = (event) => {
        const pictureUrl = event.target.result;
        setFormData({
          ...formData,
          picture: pictureUrl,
        });
      };

      reader.readAsDataURL(file);
    }
  };

  const handleAddUser = () => {
    if (formData.firstName !== '' && formData.lastName !== '') {
      setUserList([...userList, { ...formData, dateTime: new Date() }]);
      setFormData({
        firstName: '',
        lastName: '',
        city: '',
        country: '',
        address: '',
        phoneNumber: '',
        language: '',
        picture: null,
      });
    }
  };

  const handleRemoveUser = (index) => {
    const updatedUserList = [...userList];
    updatedUserList.splice(index, 1);
    setUserList(updatedUserList);
  };

  return (
    <div>
      <h1 style={{  marginLeft: '35%' }}>User Information</h1>
      <input
        type="text"
        placeholder="Search by name or phone number"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        style={{ width: '60%', marginLeft: '15%' }}
      />
      <div>
        <input
          type="text"
          name="firstName"
          value={formData.firstName}
          onChange={handleChange}
          placeholder="First Name"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="lastName"
          value={formData.lastName}
          onChange={handleChange}
          placeholder="Last Name"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="city"
          value={formData.city}
          onChange={handleChange}
          placeholder="City"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="country"
          value={formData.country}
          onChange={handleChange}
          placeholder="Country"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="address"
          value={formData.address}
          onChange={handleChange}
          placeholder="Address"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="phoneNumber"
          value={formData.phoneNumber}
          onChange={handleChange}
          placeholder="Phone Number"
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <input
          type="text"
          name="language"
          value={formData.language}
          onChange={handleChange}
          placeholder="Language"
          style={{ width: '40%', marginLeft: '25%' }}
          
        />
        <input
          type="file"
          name="picture"
          accept="image/*"
          onChange={handleFileUpload}
          style={{ width: '40%', marginLeft: '25%' }}
        />
        <button onClick={handleAddUser}>Add User</button>
        <ul>
          {filteredUserList.map((user, index) => (
            <li key={index}>
              <div>
                <strong>Name:</strong> {user.firstName} {user.lastName}
              </div>
              <div>
                <strong>City:</strong> {user.city}
              </div>
              <div>
                <strong>Country:</strong> {user.country}
              </div>
              <div>
                <strong>Address:</strong> {user.address}
              </div>
              <div>
                <strong>Phone Number:</strong> {user.phoneNumber}
              </div>
              <div>
                <strong>Language:</strong> {user.language}
              </div>
              <div>
                <strong>Picture:</strong> <img src={user.picture} alt="" />
              </div>
              <div>
                <strong>Date & Time:</strong> {user.dateTime.toString()}
              </div>
              <button onClick={() => handleRemoveUser(index)}>Remove</button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default UserInfo;
