import FileDownload from 'react-file-download';

const FileHandler = {
  replaceWord: (text, searchWord, replaceWord) => {
    return text.replace(new RegExp(searchWord, 'g'), replaceWord);
  },

  downloadFile: (text) => {
    FileDownload(text, 'replaced-text.txt');
  },
};

export default FileHandler;

